var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__03fe02e0._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_f5680d9e.js")
R.c("server/chunks/_next-internal_server_app_favicon_ico_route_actions_353150a5.js")
R.m(32682)
module.exports=R.m(32682).exports
