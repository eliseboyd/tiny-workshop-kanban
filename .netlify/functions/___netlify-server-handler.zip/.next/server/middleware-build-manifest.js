globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/d59f830a2b8e768c.js",
    "static/chunks/aead43c3bcefb43f.js",
    "static/chunks/c903f9580a4b6572.js",
    "static/chunks/a4eeb46e07741350.js",
    "static/chunks/0ff0e53d3302b2ff.js",
    "static/chunks/turbopack-1ca2cc10782ed267.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];