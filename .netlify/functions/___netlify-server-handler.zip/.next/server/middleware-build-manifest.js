globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/65fbe02f49b22b6c.js",
    "static/chunks/ed871eef8b4c50af.js",
    "static/chunks/952354cdb505a279.js",
    "static/chunks/874a2ae1e8de70d8.js",
    "static/chunks/turbopack-02d1f9170b4c825c.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];